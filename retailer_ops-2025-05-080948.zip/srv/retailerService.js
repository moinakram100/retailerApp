
module.exports = cds.service.impl(async (srv) => {



});
